import java.io.*;
import java.rmi.*;
import java.rmi.server.RemoteServer;



public class FileImpl implements FileInterface 
{

   public FileImpl(String s) throws RemoteException
   {
      super();
   }

   public byte[] downloadFile(String fileName){
      try {
         
         //string for users ip
         String cIP = RemoteServer.getClientHost();
         File file = new File(fileName);
         
         //byte array for file, casted to int, length is length of file
         byte buffer[] = new byte[(int)file.length()];
         BufferedInputStream input = new BufferedInputStream(new FileInputStream(fileName));
         
         //reading buffer
         input.read(buffer,0,buffer.length);
         System.out.println(cIP + " is requesting " + fileName);
         input.close();
         return(buffer);
         
      } catch(Exception e){
         System.out.println("FileImpl: "+e.getMessage());
         e.printStackTrace();
         return(null);
      }
   }
   
   public void uploadFile(byte[] content, String fileName) 
   {
       try 
       {
         
         //making string for user ip and other declarations
         String cIP = RemoteServer.getClientHost();
         File file = new File(fileName);
         byte[] buffer = content;

         //output stream for file
         BufferedOutputStream output = new BufferedOutputStream(new FileOutputStream(fileName));
         System.out.println(cIP + " is uploading " + fileName);
         
         //was testing sending file as bytes because it was giving errors with file
         OutputStream os = new FileOutputStream(file);
         os.write(buffer);
         
         //my method to manipulate the file uploaded to chedk for differences
         file = check(file);

         os.close();
             
         output.write(buffer,0,buffer.length);
         System.out.println(fileName + " successfully uploaded");

         output.close();
             
       } catch(Exception e){
         System.out.println("FileImpl: " + e.getMessage());
         e.printStackTrace();
      }
   }

   public File check (File file) throws IOException
   {
      
      //just so it's easier to change from here
      //given.txt is the file that the user is checking against
      final String FILENAME1 = "given.txt";
      final String FILENAME2 = file.getName();

      //variables for calculating similarity percentage
      double diff = 0;
      double linecounter = 0;
      double percent = 0;

      try 
      {

         //buffered readers for both files
         BufferedReader buffer1 = new BufferedReader(new FileReader(FILENAME1));
         BufferedReader buffer2 = new BufferedReader(new FileReader(FILENAME2));

         //line1 keeps track of the current line for file 1, and line2 is for file2, they're always at the same line, just different files
         String line1 = buffer1.readLine();
         String line2 = buffer2.readLine();

         //boolean for if both files are the same
         boolean isEqual = true;

         //keeps track of general line number for the print statements
         int lineNumber = 1;

         //while there are still lines to be read in both files (they both need to be same length, if one has more lines, it will stop checking after the last line of the shorter file)
         while(line1!=null && line2!=null)
         {
            //if the lines are not equal
            if(!line1.contentEquals(line2))
            {
               //if any line is different, they are automatically not the same
               isEqual = false;

               System.out.println(FILENAME1 + " has: " + line1 + " while " + FILENAME2 + " has: " + line2 + " at line: " + lineNumber);
               //increment counter for number of differences
               diff++;
            }

            line1 = buffer1.readLine();
            line2 = buffer2.readLine();

            //increment line counters
            lineNumber++;
            linecounter++;

         }

         if(isEqual)
            System.out.println("The two files are the same");

         buffer1.close();
         buffer2.close();

      } catch (IOException e) {
      e.printStackTrace();
      }

      //calculate similarity percentage
      percent = (diff/linecounter) * 100;
      System.out.println("Similarity percent = " + percent + "%");

      return file;
   }
}