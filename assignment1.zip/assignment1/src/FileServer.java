import java.rmi.registry.Registry;
import java.rmi.registry.LocateRegistry;
import java.rmi.server.UnicastRemoteObject;

public class FileServer {
   public static void main(String argv[]) {
      
      //updated rmi security manager
      if(System.getSecurityManager() == null) {
         System.setSecurityManager(new SecurityManager());
      }
      try {
         String name = "FileServer";
         
         //making new file interface for file name given
         FileInterface fi = new FileImpl(name);
         FileInterface stub = (FileInterface) UnicastRemoteObject.exportObject(fi, 0);
         Registry reg = LocateRegistry.getRegistry();
         reg.rebind(name, stub);
         
         System.out.println("Server is running");
         System.out.println("FileServer bound in registry");
         
      } catch(Exception e) {
         System.out.println("FileServer: "+e.getMessage());
         e.printStackTrace();
      }
   }
}