import java.io.*; 
import java.rmi.*;


public class FileClient{
   public static void main(String argv[]) {
      //if there aren't 3 arguments when invoked
      if(argv.length != 3) {
        System.out.println("Usage: java FileClient fileName machineName upload/download");
        System.exit(0);
      }
      try {
         //make string = last argument
         String wow = argv[2];

         //if they want to download
         if (wow.equals("download")) {
             System.out.println("working");
             String name = "//" + argv[1] + "/FileServer";
             FileInterface fi = (FileInterface) Naming.lookup(name);
             
             //create byte array and set it to first argument
             byte[] filedata = fi.downloadFile(argv[0]);
             File file = new File(argv[0]);
             
             //make buffered output stream
             BufferedOutputStream output = new BufferedOutputStream(new FileOutputStream(file.getName()));
             System.out.println(argv[0] + " is being downloaded...");
             
             //write the file data
             output.write(filedata,0,filedata.length);
             System.out.println(argv[0] + " downloaded successfully");
            
             //close outputs
             output.flush();
             output.close();
         }
         
         //if they want to download
         else if (argv[2].equals("upload")) {
			 String name = "//" + argv[1] + "/FileServer";
			 FileInterface fi = (FileInterface) Naming.lookup(name);
			 
			 //create file object with name of first argument
          File file = new File(argv[0]);
			 byte buffer[] = new byte[(int)file.length()];
			 BufferedInputStream input = new BufferedInputStream(new FileInputStream(argv[0]));
			 
          //read buffer
          input.read(buffer,0,buffer.length);
			 input.close();
			 fi.uploadFile(buffer, argv[0]);
             System.out.println(argv[0] + " successfully uploaded");
         }
       
      } catch(Exception e) {
         System.err.println("FileServer exception: "+ e.getMessage());
         e.printStackTrace();
      }
   }
   
}